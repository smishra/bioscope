#ifndef _CLUSTER_MAP_H
#define _CLUSTER_MAP_H

typedef std::map<std::string, std::string::difference_type, std::less<std::string> > map_type;

#endif
