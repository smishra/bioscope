extern int GetOptions (int,  char **, EnhancerParam &) ;
extern void SearchPatterns (map_type &, char *, int, Results &, EnhancerParam &, char, char *) ;
extern void ReadPatterns (Results &, char *, bool) ;

extern char CACHE_DIR[] ;

extern int CheckGrammar (char *) ;



