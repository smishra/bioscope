#ifndef ENHANCER_DEFINES_H
#define ENHANCER_DEFINES_H

#define MAX_NAME_LENGTH          60
#define MAX_FEATURE_LENGTH       60
#define MAX_NUMBER_LENGTH        40
#define MAX_NAME_LENGTH          60
#define MAX_EXPRESSIONS          10
#define MAX_CHAR_LENGTH          2000

#define MAX_WIDTH_PIXELS         800

#define ENHANCER                 1
#define GENE                     2

#endif // ENHANCER_DEFINES_H
