#ifndef WEBSERVER_H
#define WEBSERVER_H

char WebAddress[] = "http://192.168.1.102/" ;
char EnhancerAddress[] = "cgi-bin/gbrowse/" ;

#endif

