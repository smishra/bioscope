#include <stdio.h>
#include <fstream>
#include <iostream>
#include <map>
#include <vector>
#include <algorithm>
#include <EnhancerClass.h>
#include <EnhancerParam.h>
#include <EnhancerGlobalExtern.h>

extern void PerformAlone(int, char **) ;

 int main(int argc, char* argv[])
 {

   PerformAlone (argc, argv) ;
   
  
   return 0;
 }


