extern int GetOptions (int,  char **, EnhancerParam &) ;
extern void PerformMatches (EnhancerParam &) ;
