#ifndef ENHANCER_CLASS
#define ENHANCER_CLASS

typedef std::map<std::string, std::string::difference_type, std::less<std::string> > map_type;

#endif

