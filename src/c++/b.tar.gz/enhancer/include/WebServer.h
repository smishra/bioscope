#ifndef WEBSERVER_H
#define WEBSERVER_H

char WebAddress[] = "http://69.237.120.190/" ;
char EnhancerAddress[] = "cgi-bin/gbrowse/" ;

#endif

