#include <EnhancerResults.h>
#include <string.h>
#include <unistd.h>
#include <EnhancerDefines.h>
#include <WebServer.h>
 #include <boost/filesystem/operations.hpp>
 #include <boost/filesystem/path.hpp>

extern bool EvaluateConditions(char *, int *) ;
extern bool PositionOrder (const ResultClass *, const ResultClass *) ;
extern void GetNearByGenes (long, long, string &, vector <Annotation *> &, EnhancerParam &, string&, string &, string &, bool &) ;
char *color[] = {"red", "orange", "green", "cyan", "brown", "purple", "black", "violet", "peachbuf", "magenta"} ;

void BuildImageMapStr (long , long , long , long , int ,  bool , string &, string & ) ;


void 
Results::OutputResults (EnhancerParam &Param, Sequence::Fasta  &Sequence, vector <Annotation *> & Glist)

{

  int NumberofSites = Param.GetNumberofBindingSites() ;
  int Width = Param.GetWidthConstraint() ;
  vector <string> ClusterInfo(5) ;
  string BooleanConstraints = Param.GetConditionConstraint() ;
  int start, TotalResults ;
  int Count ;
  int LastSite ;
  int ClusterCount = 1 , ClusterLogicCount = 1, ClusterGeneCount =1 ;
  int ClusterSatisfying = 1 ;
  string html ;
  char buffer [2000] ;
  char donefilename [1000] ;
  char gfffilename [1000] ;
  char menufilename [1000] ;
  char noresult[1000] ;
  char SaveClusterFilename [1000] ;
  char SummaryClusterFilename [1000] ;
  string tempdonebuffer ;
  bool FoundValue ;
  ofstream donefile, gfffile, menufile ;
  fstream SaveCluster ;
  fstream SummaryCluster ;
  string description ;
  string xml ;
  string GeneXmlStr ;

  namespace fs = boost::filesystem;
   
  strcpy (SaveClusterFilename, Param.GetSaveFileName()) ;
  strcat (SaveClusterFilename, Param.GetChName()) ;
  strcpy (SummaryClusterFilename, SaveClusterFilename) ;
  strcat (SaveClusterFilename, ".res") ;
  strcat (SummaryClusterFilename, ".sum") ;
  if (fs::exists (SaveClusterFilename))
    {
      unlink (SaveClusterFilename) ;
    }
  if (fs::exists (SummaryClusterFilename))
    {
      unlink (SummaryClusterFilename) ;
    }
  
  string donebuffer ;
  donebuffer.reserve(16384) ;

  tempdonebuffer.reserve (16384)  ;

  strcpy (donefilename,(char *) Param.GetDirectoryName()) ;
  strcat (donefilename, (char *) Param.GetChName()) ;
  strcat (donefilename, ".done") ;
  strcpy (gfffilename,(char *) Param.GetDirectoryName()) ;
  strcat (gfffilename, (char *) Param.GetChName()) ;
  strcat (gfffilename, ".gff") ;
  strcpy (menufilename,(char *) Param.GetDirectoryName()) ;
  strcat (menufilename, "index.html") ;
  strcpy (noresult,(char *) Param.GetDirectoryName()) ;
  strcat (noresult, (char *) Param.GetChName()) ;
  strcat (noresult, ".nores") ;


  ClusterInfo[0].reserve(8192) ;
  ClusterInfo[1].reserve(8192) ;
  ClusterInfo[2].reserve(8192) ;
  ClusterInfo[3].reserve(8192) ;
  ClusterInfo[4].reserve(8192) ;

  donefile.open (donefilename, ios::out) ;
  gfffile.open (gfffilename, ios::app) ;
  menufile.open (menufilename, ios::out) ;
  string Results ;
  char ChromosomeName[100] ;
  const char *underscore ;
  char WebBuffer[1000] ;
  string temp ;
  temp.reserve (8192) ;
  string ImageStr ;

  description = "" ;

  temp = "" ; 
  xml = "" ;
  GeneXmlStr = "" ;
  ImageStr.reserve (8192) ;
  ImageStr = "" ;
  int FileNotOpened = 1 ;

  html.reserve (65536) ;
  Results.reserve (65536) ;

  underscore = strchr (Param.GetChName(), '_') ;
  if (strstr(Param.GetChName(), Param.GetOrganismName()))
      strcpy (ChromosomeName, &(underscore[1])) ;
  else
    strcpy (ChromosomeName, Param.GetChName()) ;
  
  xml += "<?xml version="1.0" standalone="yes"?>" ;
  
  html += "<html> \n<head>" ;
  html += "</head>\n" ;
  html += "<img src=\"http://192.168.1.102/graphics/clear.gif\"><p>" ;
  html += "<body>\n "  ;

  stable_sort (ResultList.begin(), ResultList.end(), PositionOrder)  ;
  TotalResults = ResultList.size() ;
  int ResultCount ;
  ResultCount = 0 ;
  //  for (ResultCount = 0 ; ResultCount < TotalResults ; ResultCount++)
  while (ResultCount < TotalResults)
    {
      start = ResultCount ;
      if ((start + NumberofSites) > TotalResults)
	break ;
      LastSite = NumberofSites ;
      while (((start + LastSite) < TotalResults) &&
	     ((ResultList[start+ LastSite]->GetPosition() -
	       (ResultList[start]->GetPosition()) <= Width)))
	LastSite++ ;
      ResultCount = ResultCount++ ;
      char PrecedencePattern[40] ;
      memset (PrecedencePattern, '\0', 40) ;
      if ((ResultList[start+ (LastSite - 1)]->GetPosition() - 
 	  (ResultList[start]->GetPosition()) <= Width))
	{
	  ClusterSatisfying++ ;
	  memset(SitesCount, 0, sizeof(int) * 26) ;
	  for (Count = start ; Count < (start + LastSite) ; Count++)
	    {
	      char buff[3] ;
	      (SitesCount[ResultList[Count]->GetName() - 0x41])++ ;
	      buff[0] = ResultList[Count]->GetName() ;
	      if (ResultList[Count]->GetType() == 'r')
		buff[1] = '<' ;
	      else
		buff[1] = '>' ;
	      buff[2] = '\0' ;
	      strcat (PrecedencePattern, buff) ;
	    }
 	  if ((BooleanConstraints.length() == 0) || EvaluateConditions((char *) BooleanConstraints.c_str(), SitesCount))
	    {
	      ClusterInfo[0] = "<tr><td><b>Name</b></td>" ;
	      ClusterInfo[1] =  "<tr><td><b>Pattern</b></td>" ;
	      ClusterInfo[2] = "<tr><td><b>Orientation</b></td>" ;
	      ClusterInfo[3] =  "<tr><td><b>Distance<br>(Next Site)</b></td>" ;
	      ClusterInfo[4] =  "" ;
	      
	      long start_gene, end_gene ;
	      
	      if (Param.GetDirection() == 'b')
		{
		  start_gene = ResultList[start]->GetPosition() - (Param.GetDisplay()/2) ;
		  end_gene = ResultList[start]->GetPosition() + (Param.GetDisplay()/2)  ;
		  if (start_gene < 0) start_gene = 0 ;
		  if (end_gene > Sequence.length()) end_gene = Sequence.length() - 1 ;
		}
	      if (Param.GetDirection() == 'l')
		{
		  start_gene = ResultList[start]->GetPosition() - Param.GetDisplay() ;
		  end_gene = ResultList[start]->GetPosition() + 100 ;
		  if (start_gene < 0) start_gene = 0 ;
		  if (end_gene > Sequence.length()) end_gene = Sequence.length() - 1 ;
		}
	      if (Param.GetDirection() == 'r')
		{
		  start_gene = ResultList[start]->GetPosition() - 100 ;
		  end_gene = ResultList[start]->GetPosition() + Param.GetDisplay() ;
		  if (start_gene < 0) start_gene = 0 ;
		  if (end_gene > Sequence.length()) end_gene = Sequence.length() - 1 ;
		}

	      tempdonebuffer.erase(tempdonebuffer.begin(), tempdonebuffer.end()) ;
	      FoundValue = false ;
	      GetNearByGenes (ResultList[start]->GetPosition(),
			      ResultList[start + (LastSite-1)]->GetPosition(),
			      temp, Glist, Param, tempdonebuffer, GeneXmlStr, ImageStr, FoundValue) ;
			      //	      fprintf (stderr, "%s\n", FoundValue ? "true" : "false" ) ;
	      if (FoundValue)
		{
		  if (Param.FindPrecedence (PrecedencePattern))
		  {	
		    //		    cout << "came here inside " << endl ;

		    ResultCount += LastSite - 1 ; 
		    
		    if (FileNotOpened)
		      {
			SaveCluster.open (SaveClusterFilename, ios::out | ios::binary) ;
			SummaryCluster.open (SummaryClusterFilename, ios::out) ;
			FileNotOpened = 0 ;
		      }
		    SaveCluster.write ((char *) &LastSite, sizeof(int)) ;

		    
		    sprintf (buffer, "<h3>%s, Cluster-%d, Nearby Gene Information </h3>", Param.GetChName(), ClusterCount) ;
		    donebuffer += buffer ;
		    donebuffer += tempdonebuffer.c_str() ;
		    donebuffer += "<br>" ;

		    sprintf (WebBuffer, "%s%s%s_%s?name=%s:%d..%d&span=%d", WebAddress, EnhancerAddress, Param.GetSessionName(), Param.GetChName(), ChromosomeName, start_gene, end_gene, end_gene-start_gene) ;

	      // removed true temporarily in the sprintf 
		    sprintf (buffer, "<a href=\"%s\"><h3>Cluster %d (graphical view in Generic Browser)</h3></a>", WebBuffer, ClusterCount) ;
		    html += buffer ; 
		    char *Ch = strchr (Param.GetChName(), '_') ;
		    ++Ch ;
		    sprintf (buffer,  "%s\tcig\tcluster\t%d\t%d\t.\t.\t.\tCluster %d\n", Ch, ResultList[start]->GetPosition()+1,(ResultList[start+LastSite-1]->GetPosition() + ResultList[start+LastSite-1]->GetLength()), ClusterCount) ;
		    Results += buffer ;
		    sprintf (buffer,  "cluster-%d", ClusterCount) ;
		    description = "" ;
		    description += buffer ;
		    //		    cout << "Came befoer print results" << endl ;
		    BuildImageMapStr (ResultList[start]->GetPosition(),
				   ResultList[start+LastSite - 1]->GetPosition() +
				   ResultList[start+LastSite -1]->GetLength(),
				   start_gene,
				   end_gene,
				   ENHANCER,
				   false,
				   ImageStr,
				   description   ) ;
		    description.erase (description.begin(), description.end()) ;

		    //		   		    cout << ImageStr << endl ;
				   
		    PrintResults (Param, start, start + LastSite, Sequence, Results, ClusterCount, ClusterInfo, SaveCluster, xml) ;
		    //		    cout << "Came after print results" << endl ;
		    ClusterInfo[0] += "</tr>" ;
		    ClusterInfo[1] += "</tr>" ;
		    ClusterInfo[2] += "</tr>" ;
		    ClusterInfo[3] += "</tr>" ;
		    ClusterInfo[4] += "</td></tr></table></td></tr></table>" ;
		    //	      ClusterInfo[4] += "</tr>" ;
		    //	      cout << "Came here berfore get new genes" << endl ;
		    html += "<center><table border=1>" ;
		    html +=  ClusterInfo[0].c_str() ;
		    html +=  ClusterInfo[1].c_str() ;
		    html +=  ClusterInfo[2].c_str() ;
		    html +=  ClusterInfo[3].c_str() ;
		    html += "</table></center>" ;
		    html +=  ClusterInfo[4].c_str() ;
		    ClusterInfo[0].erase (ClusterInfo[0].begin(),
					  ClusterInfo[0].end()) ;
		    ClusterInfo[1].erase (ClusterInfo[1].begin(),
					  ClusterInfo[1].end()) ;
		    ClusterInfo[2].erase (ClusterInfo[2].begin(),
					  ClusterInfo[2].end()) ;
		    ClusterInfo[3].erase (ClusterInfo[3].begin(),
					  ClusterInfo[3].end()) ;
		    ClusterInfo[4].erase (ClusterInfo[4].begin(),
					  ClusterInfo[4].end()) ;
		    html+= "<table border=1> <caption> <b> Graphics View of Cluster and Genes Nearly</b><tr><td><table>" ;
		    html+= ImageStr.c_str() ;
		    html+= "</table></td></tr></table>" ;
		    ImageStr.erase() ; 
		    html += temp.c_str() ;
		    menufile << html ;
		    menufile.flush() ;
		    gfffile << Results.c_str()  ;
		    gfffile.flush() ;
		    Results.erase (Results.begin(), Results.end()) ;
		    //		    cout << html.length() << "inside length" << endl ;
		    html.erase (html.begin(), html.end()) ;
		    //		    cout << html.length() << "erase length" << endl ;
		    ClusterCount++ ;
		  }
               else
		  {
		  }
		  ClusterGeneCount++ ;
		}
	      else
		{
		}
		  ClusterLogicCount++ ;
	    }
	}
      //      cout << "came hre at teh end" << endl ;
    }
   if (ClusterCount == 1) 
    {
      ofstream nores(noresult) ;
      nores << "noresult" << endl ;
      nores.close() ;
    }
  gfffile.close() ;

  //  cout << html.length() << "length" << endl ;

  //#ifdef DEBUG 
  vector <PatternClass *> PatternLists ;
    int count ;
    PatternLists = Param.GetPatternLists () ;
    donefile << "<table border=1>" << endl ;
    if (fs::exists (SummaryClusterFilename))
      SummaryCluster << "<table border=1>" << endl ;
    for (count = 0 ; count < PatternLists.size() ; count++) 
      {
      	donefile << "<tr><td><font color=" << color[count] << ">" << PatternLists[count]->GetPatternName() << "-" <<  PatternLists[count]->GetPattern() << "</font></td><td>" << (PatternLists[count]->GetNumberofForward()+ PatternLists[count]->GetNumberofReverse()) << "</td></tr>" << endl ;
	if (fs::exists (SummaryClusterFilename))
	  SummaryCluster << "<tr><td><font color=" << color[count] << ">" << PatternLists[count]->GetPatternName() << "-" <<  PatternLists[count]->GetPattern() << "</font></td><td>" << (PatternLists[count]->GetNumberofForward()+ PatternLists[count]->GetNumberofReverse()) << "</td></tr>" << endl ;

      }

    html += "</body></html>" ;
    menufile << html ;
    menufile.flush() ;
    menufile.close() ;

  donefile << "<tr><td>No-of-" << Param.GetNumberofBindingSites() << "-Sites-within-" << Param.GetWidthConstraint() << "-bases</td><td>" << (ClusterSatisfying-1) << "</td></tr>" << endl ;
  donefile << "<tr><td> Total after satisfying " << Param.GetConditionConstraint() << "</td><td>" << ClusterLogicCount-1 << "</td></tr>" << endl  ;
  donefile << "<tr><td> FinalTotal after satisfying Gene Specific Constraints</td><td>" << ClusterGeneCount-1 << "</td></tr>" << endl  ;
  donefile << "<tr><td> FinalTotal after satisfying Precedence/orientation constraints</td><td>" << ClusterCount-1 << "</td></tr></table>" << endl  ;

  if (fs::exists (SummaryClusterFilename))
    {
      SummaryCluster << "<tr><td>No-of-" << Param.GetNumberofBindingSites() << "-Sites-within-" << Param.GetWidthConstraint() << "-bases</td><td>" << (ClusterSatisfying-1) << "</td></tr>" << endl ;
      SummaryCluster << "<tr><td> Total after satisfying " << Param.GetConditionConstraint() << "</td><td>" << ClusterLogicCount-1 << "</td></tr>" << endl  ;
      SummaryCluster << "<tr><td> FinalTotal after satisfying Gene Specific Constraints</td><td>" << ClusterGeneCount-1 << "</td></tr>" << endl  ;
      SummaryCluster << "<tr><td> FinalTotal after satisfying Precedence/orientation constraints</td><td>" << ClusterCount-1 << "</td></tr></table>" << endl  ;
    }

    //#endif

    if (ClusterCount <= 5) 
      {
	donefile << donebuffer.c_str() << "</table>"<< endl ;
      }
    
    donefile.flush() ;
    donefile.close() ;
    if (fs::exists(SaveClusterFilename))
      {
	SaveCluster.close() ;
      }
    if (fs::exists(SummaryClusterFilename))
      {
	SummaryCluster.close() ;
      }
    donebuffer.erase() ;
    html.erase() ;
    Results.erase() ;
    //    cout << html.length() << "length" << endl ;
  
}


void 
Results::PrintResults (EnhancerParam &Param, int start, int end, Sequence::Fasta &fastaseq, string &results, int cluster, vector<string> &htm, fstream &SaveCluster, string &xml)

{

  int PrintCount ;
  int Position ;
  static string seq ;
  int from, to ;
  char ch ;
  char buffer [1000] ;
  char htmlbuffer[1000] ;
  long BeginPosition, FillLengthPosition, LengthPosition ;
  int BreakPosition ;

      BeginPosition = 0 ; 
      LengthPosition = 0 ;
      FillLengthPosition = 0 ;
      int PageCut = 0 ;


  if (!seq.length()) 
    {
      seq = fastaseq.GetSeq().c_str() ;
    }
  

    int BeginSubstr ;
    int EndSubStr ;

    BeginSubstr = ResultList[start]->GetPosition() - 200 ;
    if (BeginSubstr < 0)
      BeginSubstr = 0 ;

    sprintf (buffer, "<TABLE BORDER=\"1\" CELLPADDING=\"2\" CELLSPACING=\"0\" WIDTH=\"200\" BGCOLOR=\"#FF0000\"><caption> <b> Cluster Sequence </b></caption><tr><td><TABLE BORDER=\"1\" CELLPADDING=\"2\" CELLSPACING=\"0\" WIDTH=\"100%\" BGCOLOR=\"#FFFFFF\"><tr><td>") ;
   htm[4] +=  buffer ;

    if (BeginSubstr == 0) 
      EndSubStr = ResultList[start]->GetPosition() ;
    else
      EndSubStr = 200 ;

    while (EndSubStr > 0)
      {
	if (EndSubStr > 60)
	  {
	    sprintf (buffer, "<font color=black>%s</font><br>", (seq.substr(BeginSubstr, 60).c_str())) ;
	    BeginSubstr += 60 ;
	    EndSubStr -= 60 ;
	    htm[4]+= buffer ;
	  }
	else
	  {
	    sprintf (buffer, "<font color=black>%s</font><br>", (seq.substr(BeginSubstr, EndSubStr).c_str())) ;
	    BeginSubstr += EndSubStr ;
	    EndSubStr = 0  ;
	    htm[4]+= buffer ;
	  }
      }
    htm[4] += "</td></tr><tr><td>" ;

   for (PrintCount = start ; PrintCount < end ; PrintCount++)
     {

       if (PrintCount == start)
	 {
	 }
       else
	 {
	   from = ResultList[PrintCount-1]->GetPosition()+ ResultList[PrintCount-1]->GetLength() ;
	   to = ResultList[PrintCount]->GetPosition() - (ResultList[PrintCount-1]->GetPosition() + ResultList[PrintCount-1]->GetLength()) ;
 #ifdef DEBUG	  
	   if (to >= 0)
	     cout << seq.substr(from, to) << "  " ;
 #endif
	 }

       if (PrintCount == start)
	 {
	   BeginPosition = ResultList[PrintCount]->GetPosition() ;
	   LengthPosition  =  ResultList[PrintCount]->GetLength() ;
	 }
       else
	 {
	   if ((ResultList[PrintCount-1]->GetPosition()+ ResultList[PrintCount-1]->GetLength()) >
	       ResultList[PrintCount]->GetPosition())
	   {

	     BeginPosition = ResultList[PrintCount-1]->GetPosition() + ResultList[PrintCount-1]->GetLength() ;
	     LengthPosition = ResultList[PrintCount]->GetPosition() + ResultList[PrintCount]->GetLength() - BeginPosition ;
	     if ((ResultList[PrintCount]->GetPosition() + 
		  ResultList[PrintCount]->GetLength()) < 
		 (ResultList[PrintCount-1]->GetPosition()+ ResultList[PrintCount-1]->GetLength()))
	       {
		 LengthPosition = 0 ;
	       }
	   }
	 }

       if (PrintCount+1 != end)
	 {
	   if ((ResultList[PrintCount]->GetPosition() + 
		ResultList[PrintCount]->GetLength()) > ResultList[PrintCount+1]->GetPosition())
	     {
	       BeginPosition = ResultList[PrintCount]->GetPosition() ;
	       LengthPosition = ResultList[PrintCount+1]->GetPosition() - 
		 ResultList[PrintCount]->GetPosition() ;
	     }
	   else
	     {
	       BeginPosition = ResultList[PrintCount]->GetPosition() ;
	       LengthPosition = ResultList[PrintCount]->GetLength() ;
	     }
	 }
       else
	 {
	       BeginPosition = ResultList[PrintCount]->GetPosition() ;
	       LengthPosition = ResultList[PrintCount]->GetLength() ;
	 }

       if (PrintCount != (end -1))
	 {
	   FillLengthPosition = ResultList[PrintCount+1]->GetPosition() - 
	     (ResultList[PrintCount]->GetPosition() + ResultList[PrintCount]->GetLength()) ;
	 }
       else
	 {
	   FillLengthPosition = 0 ;
	 }


	   sprintf (htmlbuffer,  "<font color=%s>", color[(int)(ResultList[PrintCount]->GetName()) - 0x41] ) ; 
       htm[4] += htmlbuffer ;
       if ((PageCut + LengthPosition) > 60)
	 {
	   BreakPosition = PageCut + LengthPosition - 60 ;
	   PageCut = LengthPosition - BreakPosition ;
	 }
       else
	 {
	   BreakPosition = -1 ;
	   PageCut += LengthPosition ;
	 }
       if (BreakPosition != -1)
	 {
	   sprintf (buffer, "%s<br>%s</font>", (seq.substr(BeginPosition, PageCut)).c_str(), (seq.substr(BeginPosition+PageCut, BreakPosition)).c_str()) ;
	   htm[4] += buffer ;
	     //seq.substr(BeginPosition, PageCut) + "<br>" + 
	     //seq.substr(BeginPosition+PageCut, BreakPosition) + "</font>" ;
	   PageCut = BreakPosition ;
	 }
       else
	 {
	   sprintf (buffer, "%s</font>", (seq.substr(BeginPosition, LengthPosition)).c_str()) ;
	   htm[4] += buffer ;
	 }

      if (FillLengthPosition > 0)
	{
	  if ((PageCut + FillLengthPosition) > 60)
	    {
	      int Advance = 0 ;
	      BreakPosition = PageCut + FillLengthPosition  ;
	      htm[4] += "<font color=black>" ;
	      while (BreakPosition > 60)
		{
		  sprintf (buffer, "%s<br>", seq.substr(BeginPosition + LengthPosition + Advance, 60 - PageCut).c_str()) ;
		  htm[4] +=  buffer ; 
 //seq.substr(BeginPosition + LengthPosition + Advance,
 // 60 - PageCut) + "<br>" ;
		  Advance += 60 - PageCut ;
		  BreakPosition -= (60 - PageCut)  ;
		  PageCut = 0 ;
		}

	      Advance -= 60 ;
	      sprintf (buffer, "%s</font>",
		       (seq.substr(BeginPosition + LengthPosition + Advance,BreakPosition)).c_str()) ;
	      htm[4] +=  buffer ;
		//(seq.substr(BeginPosition + LengthPosition + Advance, 
		//				   BreakPosition)).c_str() + "</font>" ;
	      PageCut = BreakPosition ;
	    }

	  else 
	    {
	      sprintf (buffer, "<font color=black>%s</font>",
		       (seq.substr(BeginPosition + LengthPosition,FillLengthPosition)).c_str()) ;
	      htm[4] +=  buffer ;
		//"<font color=black>" +  (seq.substr(BeginPosition + LengthPosition,
		//		   FillLengthPosition)).c_str() + "</font>" ;
	      PageCut += FillLengthPosition ;
	    }
	}


       sprintf (htmlbuffer, "<td><font color=%s>%c</font></td>",
		color[(int)ResultList[PrintCount]->GetName() - 0x41], ResultList[PrintCount]->GetName()) ;
       htm[0] += htmlbuffer ;
       sprintf (buffer, "<td>%s</td>", (seq.substr(ResultList[PrintCount]->GetPosition(), ResultList[PrintCount]->GetLength())).c_str()) ;
       htm[1] += buffer ;
       //"<td>" +  (seq.substr(ResultList[PrintCount]->GetPosition(),
       // ResultList[PrintCount]->GetLength())).c_str() + "</td>" ;
 #ifdef DEBUG	  
       cout << "<" << ResultList[PrintCount]->GetName() << ">" ;
 #endif
       if (ResultList[PrintCount]->GetType() == 'r')
	 {
 #ifdef DEBUG	  
	   cout << "   <----  " ;
 #endif
	   htm[2] += "<td><img src=\"http://192.168.1.102/reverse.gif\"></td>" ;
	   ch = '-' ;
	 }
       else
	 {
 #ifdef DEBUG	  
	   cout << "   ---->  " ;
 #endif
	   htm[2] += "<td><img src=\"http://192.168.1.102/forward.gif\"></td>" ;
	   ch = '+' ;
	 }
       BeginPosition = 0 ; 
       LengthPosition = 0 ;
       FillLengthPosition = 0 ;
       if (PrintCount < (end -1))
	 {
	   sprintf (htmlbuffer, "<td>%d</td>", 
		    ResultList[PrintCount+1]->GetPosition() - (ResultList[PrintCount]->GetPosition() +  ResultList[PrintCount]->GetLength())) ;
	   htm[3] += htmlbuffer ;
	   //	  sprintf (htmlbuffer, "<td>%d</td>", 
	   //		   ResultList[PrintCount]->GetPosition() + ResultList[PrintCount]->GetLength()) ;
       //	  htm[4] += htmlbuffer ;
	 }

       char *Ch ;
       if (strstr(Param.GetChName(), Param.GetOrganismName()))
	 {
	   Ch = strchr (Param.GetChName(), '_') ;
	   ++Ch ;
	 }
       else
	 {
	   Ch = (char *) Param.GetChName () ;
	 }
       ResultList[PrintCount]->SaveIntoFile (SaveCluster) ;
       sprintf (buffer,  "%s\tcig\tsites\t%d\t%d\t.\t%c\t.\tcluster %d-%c\n", Ch, ResultList[PrintCount]->GetPosition()+1,(ResultList[PrintCount]->GetPosition() + ResultList[PrintCount]->GetLength()), ch, cluster, ResultList[PrintCount]->GetName()) ;
       results += buffer ;
     }

   htm[4] += "</td></tr><tr><td>" ;

    BeginSubstr = ResultList[end-1]->GetPosition() + ResultList[end -1]->GetLength() ;
    if ((BeginSubstr + 200) >= seq.length()) 
      EndSubStr = seq.length() - BeginSubstr ;
    else
      EndSubStr = 200 ;

    while (EndSubStr > 0)
      {
	if (EndSubStr > 60)
	  {
	    sprintf (buffer, "<font color=black>%s</font><br>", (seq.substr(BeginSubstr, 60).c_str())) ;
	    BeginSubstr += 60 ;
	    EndSubStr -= 60 ;
	    htm[4]+= buffer ;
	  }
	else
	  {
	    sprintf (buffer, "<font color=black>%s</font><br>", (seq.substr(BeginSubstr, EndSubStr).c_str())) ;
	    BeginSubstr += EndSubStr ;
	    EndSubStr = 0  ;
	    htm[4]+= buffer ;
	  }
      }
    
    htm[4] += "</td></tr>" ;


  cluster++ ;
  
}

void BuildImageMapStr (long start, long end, long leftend, long rightend, int type, 
		       bool orientation, string & imagestr, string &info)
{

  char imagebuffer[2000] ;

  double  steps  = (double) MAX_WIDTH_PIXELS / (double) (rightend - leftend) ;
  int leftwidth ;

  //  cout << (rightend - leftend) << endl ;
  int width ; 
      imagestr += "<tr><td>" ;
  switch (type)
    {
    case ENHANCER :
      width = (int) ((double) (start - leftend) * steps) ;
      leftwidth = width ;
      sprintf (imagebuffer, "<img src=\"./clear.gif\" width=\"%d\" height=\"4\" />",
	       width) ;
      imagestr += imagebuffer ;

      width = (int) ((double) (end  - start) * steps) ;
      sprintf (imagebuffer, "<img src=\"./1.gif\" width=\"%d\" height=\"4\" />",
	   width) ;
      imagestr += imagebuffer ;
      sprintf (imagebuffer, "<img src=\"./clear.gif\" width=\"%d\" height=\"4\" />",
	       (MAX_WIDTH_PIXELS - width - leftwidth)) ;
      imagestr += imagebuffer ;
      imagestr += "</td></tr>" ;
      break ;
    case GENE :
      if (orientation)
	{
	  if (start > leftend ) 
	    width = (int) ((double) (start - leftend) * steps) ;
	  if (start < leftend)
	    width =  0 ;
	  sprintf (imagebuffer, "<img src=\"./clear.gif\" width=\"%d\" height=\"4\" />",
		   width) ;
	  imagestr += imagebuffer ;
	  leftwidth = width ;

	  if ((start > leftend) && (end < rightend))
 	    width = (int) ((double) (end  - start) * steps) ;
	  if ((start <leftend ) && (end < rightend))
	    width = (int) ((double) (end  - leftend) * steps) ;
	  if ((start < leftend ) && (end >  rightend))
	    width = (int) ((double) (rightend  - leftend) * steps) ;
	  if ((start > leftend) && (end > rightend))
 	    width = (int) ((double) (rightend  - start) * steps) ;

	  sprintf (imagebuffer, "<img src=\"./forward.gif\"/>") ;
	  imagestr += imagebuffer ;
	  sprintf (imagebuffer, "<img src=\"./2.gif\" width=\"%d\" height=\"4\" />",
		   width) ;
	  imagestr += imagebuffer ;
	}
      else
	{
	  if (end > leftend ) 
	    width = (int) ((double) (end - leftend) * steps) ;
	  if (end < leftend)
	    width =  0 ;
	  sprintf (imagebuffer, "<img src=\"./clear.gif\" width=\"%d\" height=\"4\" />",
		   width) ;
	  imagestr += imagebuffer ;
	  leftwidth = width ;
	  if ((end > leftend) && (start < rightend))
 	    width = (int) ((double) (start  - end) * steps) ;
	  if ((end <leftend ) && (start < rightend))
	    width = (int) ((double) (start  - leftend) * steps) ;
	  if ((end < leftend ) && (start >  rightend))
	    width = (int) ((double) (rightend  - leftend) * steps) ;
	  if ((end > leftend) && (start > rightend))
 	    width = (int) ((double) (rightend  - end) * steps) ;

	  sprintf (imagebuffer, "<img src=\"./2.gif\" width=\"%d\" height=\"4\" />",
		   width) ;
	  imagestr += imagebuffer ;
	  sprintf (imagebuffer, "<img src=\"./reverse.gif\"/>") ;
	  imagestr += imagebuffer ;
	  sprintf (imagebuffer, "<img src=\"./clear.gif\" width=\"%d\" height=\"4\" />",
		   (MAX_WIDTH_PIXELS - width - leftwidth)) ;
	  imagestr += imagebuffer ;
	  imagestr += "</td></tr>" ;
	}

      break ;
    default : 
      ;
    }

  imagestr += "</td></tr>" ;
  imagestr += "<tr><td>" ;
  sprintf (imagebuffer, "<img src=\"./clear.gif\" width=\"%d\" height=\"4\" />",
	   leftwidth-10) ;
  imagestr += imagebuffer ;
  sprintf (imagebuffer, "<font size=\"2\"><b>%s</b></font></td></tr>", info.c_str()) ;
  imagestr += imagebuffer ;
  return ;
}
